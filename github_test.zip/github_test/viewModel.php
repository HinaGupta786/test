<?php include('api/action.php');
$data = $obj->getDataById('tbl_model_list',$_REQUEST['id']);
$result1 = json_decode($data,true);
$result = $result1[0];
?>
<html>
	<head>
		<title>CDMX TEST</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
		  <h2 class="form-heading">Edit Model</h2>
		  <div class="error"><?php echo @$_GET['error']; ?></div>
		  <div class="success"><?php echo @$_GET['msg']; ?></div>
		  <form action=""  method="post">
		  <div class="row">
		  <div class="col-md-6">
		  <div class="form-group">
			  <label for="Manufact">Manufacture:</label>
			  <select class="form-control" id="Manufact" name="manufact_id">
				<option value="0">Select Manufacture</option>
				<?php
					$mafactListing1 = $obj->AllList('tbl_manufacturer_list','`status` = 1');
					$mafactListing = json_decode($mafactListing1,true);
					//print_r($listing1);
					if($mafactListing >= 1){
					foreach($mafactListing as $manufacture){ 
				?>
				<option value="<?php echo $manufacture['id'];?>" <?php if($result['manufacture_id'] == $manufacture['id']){echo 'selected';}?>><?php echo $manufacture['manufactor_name'];?></option>
				<?php }
				} ?>
			  </select>
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
			  <label for="Model">Model Name:</label>
			  <input type="text" class="form-control" id="Model" placeholder="Enter Model Name" name="model" value="<?php echo $result['model_name'];?>">
			</div>
			</div>
			</div>
			
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
				<label for="color">Model Color:</label>
				<input type="text" class="form-control" id="color" placeholder="Enter Model Color" name="color" value="<?php echo $result['model_color'];?>">
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
				<label for="model_year">Model Year:</label>
				<input type="text" class="form-control" id="model_year" placeholder="Enter Model Year" name="model_year" value="<?php echo $result['model_year'];?>">
			</div>
			</div>
			</div>
			
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
				<label for="registration_no">Registration No.:</label>
				<input type="text" class="form-control" id="registration_no" placeholder="Enter Model Registration No." name="registration_no" value="<?php echo $result['registration_no'];?>">
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
				<label for="description">Description:</label>
				<textarea name="description" id="description" class="form-control" placeholder="Type Description"><?php echo $result['description'];?></textarea>
			</div>
			</div>
			</div>
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
			  <label for="manufactStatus">Status:</label>
			  <select class="form-control" id="manufactStatus" name="status">
				<option value="1">Enable</option>
				<option value="0">Disable</option>
			  </select>
			  <input type="hidden" name="action" value="update">
			  <input type="hidden" name="id" value="<?php echo $result['id'];?>">
			</div>
			</div>
			</div>
			<div class="row">
			<div class="col-md-6"></div>
			<div class="col-md-6">
			<button type="submit" name="UpdateModel" class="btn btn-primary">Update</button>
			</div>
			</div>
		  </form>
		</div>
	</body>
</html>