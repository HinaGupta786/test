<?php
define('MYSQL_HOST', 'localhost');
define('MYSQL_LOGIN', 'root');
define('MYSQL_PASSWORD', '1234');
define('MYSQL_DB', 'cdmx_db');
define('LOG_FILE', 'php-errors.log');

?>