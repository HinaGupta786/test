<?php
 /*
 * Constants Class
 * Set DataBase Connection
 *
 */
require_once ('constants.php');
class DB
{
    /**
     * Host Name
     *
     * @var string
     */
    const mysqlhost = MYSQL_HOST;

    /**
     * Username
     *
     * @var string
     */
    const mysql_login =MYSQL_LOGIN;

    /**
     * Password
     *
     * @var string
     */
    const mysql_password =MYSQL_PASSWORD;

    /**
     * Database name
     *
     * @var string
     */
    const database =MYSQL_DB;

    /**
     * Connection string
     *
     * @var string
     */
    public $con;

    /**
     * Constructor
     *
     * @return void
     */
    function __construct()
    {
        $this->con = $this->connectdb();
    }

    /**
     * Connecting to database
     *
     * @return object
     */
    private function connectdb()
    {
        if (!($db = mysqli_connect(self::mysqlhost, self::mysql_login, self::mysql_password, self::database))) {
            die ('MySQL connect failed. ' .mysqli_connect_error() );
        } else {             
            return $db;
        }
    }
}
?>
