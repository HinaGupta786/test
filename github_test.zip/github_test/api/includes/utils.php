<?php
/* This file contains some util functions used by all the php scripts*/

/* Generate a random password of 8 characters and return it.*/
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

/* Send a forgot email password.
* -- email : The email is to which the mail has to be sent
* -- password : New password of the user
*/
function send_forgot_password_mail($email, $password)
{
	$to = $email;
	$subject = "MCHW App - Forgot Password";
	$message = "<html>"
			   ."<body>"
			   ."Your password has been reset.<br>"
			   ."Your new password is : <span style='color:blue'>".$password."</span><br><br>"
			   ." You can login using this password. Please change your password after logging in.<br><br>"
			   ."Thanks,<br> MCHW App Team"
			   ."</body></html>";
	
	$from = "admin@mchw.mobi";
	$headers = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'From: '.$from . "\r\n";
	
	mail($to,$subject,$message,$headers);
}

?>