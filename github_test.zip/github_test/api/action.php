<?php
include('api/api.php');
$obj = new api("json");
if(isset($_POST['AddManufacture'])){
	//echo $_POST['manufacture'];exit;
	$isDone = $obj->ManufactureAction('',$_POST['manufacture'],$_POST['status'],$_POST['action']);
	if($isDone == 1){
		$msg = "Successfully Added";
		header('location:dashboard.php?msg'.$msg);
	}else{
		$error = 'This Content can not be added';
		header('location:dashboard.php?error='.$error);
	}
}
if(isset($_POST['UpdateManufacture'])){
	//echo $_POST['manufacture'];exit;
	$isDone = $obj->ManufactureAction($_POST['id'],$_POST['manufacture'],$_POST['status'],$_POST['action']);
	if($isDone == 1){
		$msg = "Successfully Added";
		header('location:dashboard.php?msg'.$msg);
	}else{
		$error = 'This Content can not be Update';
		header('location:dashboard.php?error='.$error);
	}
}
if(isset($_POST['AddModel'])){
	$isDone = $obj->ModelAction('',$_POST['manufact_id'],$_POST['model'],$_POST['color'],$_POST['model_year'],$_POST['registration_no'],$_POST['description'],$_POST['status'],$_POST['action']);
	if($isDone == 1){
		$msg = "Successfully Added";
		header('location:add_model.php?msg'.$msg);
	}else{
		$error = 'This Content can not be added';
		header('location:add_model.php?error='.$error);
	}
}
if(isset($_POST['UpdateModel'])){
	$isDone = $obj->ModelAction($_POST['id'],$_POST['manufact_id'],$_POST['model'],$_POST['color'],$_POST['model_year'],$_POST['registration_no'],$_POST['description'],$_POST['status'],$_POST['action']);
	if($isDone == 1){
		$msg = "Successfully Added";
		header('location:add_model.php?msg'.$msg);
	}else{
		$error = 'This Content can not be Update';
		header('location:add_model.php?error='.$error);
	}
}


?>