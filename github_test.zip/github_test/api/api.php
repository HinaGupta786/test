<?php
//header('Content-Type: application/json; charset=utf-8', true, 200);
header('Access-Control-Allow-Origin: *');
//Connection to database
require_once ('includes/connect.inc.php');
error_reporting(1);
class api {

    //Object to DB class
    protected $db;
	
	//Result from the functions
    public $output;

    public function __construct($format = 'json') {
        $this->db = new DB;
    }

    function errorlog() {
        echo mysqli_error($this->db->con) . "\t\t" . date('d-m-Y H:i:s') . "\n";
        error_log(mysqli_error($this->db->con) . "\t\t" . date('d-m-Y H:i:s') . "\n", 3, LOG_FILE);
        die('An error occured while processing your request.Please try again.');
    }

    //Check user authorisation
    function login($email, $password) {
        $sql_query = "SELECT * FROM `tbl_user` WHERE `email_id` = '" . $email . "' AND `password`='" . $password . "'";
        $result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
        $numrows = mysqli_num_rows($result);
        //header("Content-type: application/json");
        $output = "";
        if ($numrows == 0)
            return false;
        else
            return true;
    }
	function ManufactureAction($manufactureId, $manufactureName, $status, $action){
		if($action == 'update'){
			$sql_query = "SELECT * from `tbl_manufacturer_list` where `id` = '".$manufactureId."'";
			$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
			$numrows = mysqli_num_rows($result);
			if($numrows >= '1'){
				$sql_query = "update `tbl_manufacturer_list` set `manufactor_name` = '".$manufactureName."',`status` = '".$status."' WHERE `id` = '".$manufactureId."'";
				$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
				$finalResult = '1';
			}
		}if($action == 'add'){
			$sql_query = "SELECT * from `tbl_manufacturer_list` where `manufactor_name` = '".$manufactureName."'";
			$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
			$numrows = mysqli_num_rows($result);
			if($numrows == 0){
				$sql_query = "INSERT into `tbl_manufacturer_list`(`manufactor_name`,`status`) value('".$manufactureName."','".$status."')";
				$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
				$finalResult = '1';
			}
		}
		
        if ($finalResult == 0)
            return false;
        else
            return true;
	}
	function ModelAction($modelId,$manufactureId, $manufactureName, $color, $year, $registration_no, $description, $status, $action){
		if($action == 'update'){
			$sql_query = "SELECT * from `tbl_model_list` where `id` = '".$modelId."'";
			$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
			$numrows = mysqli_num_rows($result);
			if($numrows >= '1'){
				$sql_query = "update `tbl_model_list` set `manufacture_id` = '".$manufactureId."', `model_name` = '".$manufactureName."',`model_color` = '".$color."', `model_year` = '".$year."',`registration_no` = '".$registration_no."',`description` = '".$description."', `status` = '".$status."' WHERE `id` = '".$modelId."'";
				$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
				$finalResult = '1';
			}
		}if($action == 'add'){
			$sql_query = "SELECT * from `tbl_model_list` where `model_name` = '".$manufactureName."'";
			$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
			$numrows = mysqli_num_rows($result);
			if($numrows == 0){
				$sql_query = "INSERT into `tbl_model_list`(`manufacture_id`,`model_name`,`model_color`, `model_year`, `registration_no`,`description`,`status`) value('".$manufactureId."','".$manufactureName."','".$color."', '".$year."', '".$registration_no."','".$description."','".$status."')";
				$result = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
				$finalResult = '1';
			}
		}
		
        if ($finalResult == 0)
            return false;
        else
            return true;
	}
	function AllList($table,$where){
		$sql_query = "SELECT * from `".$table."` where ".$where;
		$data = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
		$numrows = mysqli_num_rows($data);
		while ($result = mysqli_fetch_assoc($data)) {
			$finalResult[] = $result;
		}
		$output = "";
		if ($numrows == 0)
            return false;
        else
            return $output = json_encode($finalResult);
	}
	
	function getDataById($table,$id){
		$sql_query = "SELECT * from `".$table."` where `id` = ".$id;
		$data = mysqli_query($this->db->con, $sql_query) or $this->errorlog();
		$numrows = mysqli_num_rows($data);
		while ($result = mysqli_fetch_assoc($data)) {
			$finalResult[] = $result;
		}
		$output = "";
		if ($numrows == 0)
            return false;
        else
            return $output = json_encode($finalResult);
	}
}
?>