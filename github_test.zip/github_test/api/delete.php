<?php 
$con = mysqli_connect('localhost','root','1234','cdmx_db');
	$manufactureId = $_REQUEST['id'];
	$table = $_REQUEST['table'];
	$sql_query = "SELECT * from `".$table."` where `id` = '".$manufactureId."'";
	$result = mysqli_query($con, $sql_query) or $this->errorlog();
	$numrows = mysqli_num_rows($result);
	if($numrows >= '1'){
		$sql_query = "DELETE FROM `".$table."` WHERE`id` = '".$manufactureId."'";
		$result = mysqli_query($con, $sql_query) or $this->errorlog();
		$finalResult = '1';
	}else{
		$finalResult = '0';
	} 	
?>
<script>
window.location.href='../dashboard.php';
</script>