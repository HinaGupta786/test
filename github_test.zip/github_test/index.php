<html>
	<head>
		<title>CDMX TEST</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
		  <h2 class="form-heading">Login Form</h2>
		  <div class="error"><?php echo @$_GET['error']; ?></div>
		  <form action="" method="post">
			<div class="form-group">
			  <label for="email">Email:</label>
			  <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
			</div>
			<div class="form-group">
			  <label for="pwd">Password:</label>
			  <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
			</div>
			<button type="submit" name="login" class="btn btn-default">Submit</button>
		  </form>
		</div>
	</body>
</html>
<?php
include('api/api.php');
$obj = new api("json");
if(isset($_POST['login'])){
	if($obj->login($_POST['email'],$_POST['password']) == 1){
		header('location:dashboard.php');
	}else{
		$error = 'Invalid Email Id or Password';
		header('location:index.php?error='.$error);
	}
}
?>