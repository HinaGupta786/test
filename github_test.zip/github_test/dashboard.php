<?php include('api/action.php');?>
<html>
	<head>
		<title>CDMX TEST</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
		  <h2 class="form-heading">Add Manufacture</h2>
		  <div class="error"><?php echo @$_GET['error']; ?></div>
		  <div class="success"><?php echo @$_GET['msg']; ?></div>
		  <form action=""  method="post">
			<div class="form-group">
			  <label for="manufact">Manufacture:</label>
			  <input type="text" class="form-control" id="manufact" placeholder="Enter Manufacture" name="manufacture">
			</div>
			<div class="form-group">
			  <label for="manufactStatus">Status:</label>
			  <select class="form-control" id="manufactStatus" name="status">
				<option value="1">Enable</option>
				<option value="0">Disable</option>
			  </select>
			  <input type="hidden" name="action" value="add">
			</div>
			<button type="submit" name="AddManufacture" class="btn btn-default">Add</button>
		  </form>
		  <div class="row">
			<div class="col-md-12">
				<div class="col-md-10"></div>
				<div class="col-md-2">
					<a href="add_model.php" class="btn btn-warning">Add Model</a>
				</div>
			</div>
		  </div>
		  <div class="row">
			<table class="table table-hover">
				<thead>
				  <tr>
					<th>S.No.</th>
					<th>Manufacture Name</th>
					<th>Status</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
					<?php
					$listing = $obj->AllList('tbl_manufacturer_list','`status` = 1 or `status` = 0');
					$listing1 = json_decode($listing,true);
					//print_r($listing1);
					if($listing1 >= 1){
					foreach($listing1 as $manufacture){
					$count += 1;
					?>
					  <tr>
						<td><?php echo $count; ?></td>
						<td><?php echo ucfirst($manufacture['manufactor_name']); ?></td>
						<td><?php if($manufacture['status'] == 1){echo '<span class="btn btn-success">Enabled</div>';}else{echo '<div class="btn btn-primary">Disable</div>';}; ?></td>
						<td>
							<button type="button" class="btn btn-info editManufact" data-ids="<?php echo $manufacture['id']; ?>" data-vals="<?php echo $manufacture['manufactor_name']; ?>" data-toggle="modal" data-target="#manufactId_<?php echo $manufacture['id']; ?>">Edit</button>
							<button type="button" class="btn btn-danger deleteManufact" data-ids="<?php echo $manufacture['id']; ?>">Delete</button>
						</td>
					  </tr>
					<?php } 
					} ?>
				</tbody>
			  </table>
		  </div>
		</div>
		<!------- popup window coding ------->
		  <div class="modal fade dynamicPupup" id="" role="dialog">
			<div class="modal-dialog">
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>
				  <h4 class="modal-title">Edit Manufacture</h4>
				</div>
				<div class="modal-body">
				<form action="" method="post">
				  <div class="row">
				  <div class="col-md-12">
					<div class="form-group">
					  <label for="manufact">Manufacture:</label>
					  <input type="text" class="form-control manufactName" placeholder="Enter Manufacture" name="manufacture" value="">
					</div>
					<div class="form-group">
					  <label for="manufactStatus">Status:</label>
					  <select class="form-control" name="status">
						<option value="1">Enable</option>
						<option value="0">Disable</option>
					  </select>
					  <input type="text" name="action" value="update">
					  <input type="text" class="editId" name="id" value="">
					</div>
					<div class="form-group">
						<input type="submit" name="UpdateManufacture" class="btn btn-primary">
					</div>
				  </div>
				  </div>
				  </form>
				</div>
				<div class="modal-footer">
				  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			  </div>
			</div>
		  </div>
		 <script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script>
		$('.editManufact').on('click',function(){
			var popupId = $(this).attr('data-ids');
			var popupval = $(this).attr('data-vals');
			$('.dynamicPupup').attr('id','manufactId_'+popupId);
			$('.editId').attr('value',popupId);
			$('.manufactName').attr('value',popupval);
		});
		$('.deleteManufact').on('click',function(){
			var DelId = $(this).attr('data-ids');
			var isOk = confirm('Do You really want to delete?');
			if(isOk == true){
				window.location.href = 'api/delete.php?table=tbl_manufacturer_list&id='+DelId;
			}
			
		});
		</script>
	</body>
</html>
