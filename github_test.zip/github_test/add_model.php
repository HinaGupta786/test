<?php include('api/action.php');?>
<html>
	<head>
		<title>CDMX TEST</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="container">
		  <h2 class="form-heading">Add Model</h2>
		  <div class="error"><?php echo @$_GET['error']; ?></div>
		  <div class="success"><?php echo @$_GET['msg']; ?></div>
		  <form action=""  method="post">
		  <div class="row">
		  <div class="col-md-6">
		  <div class="form-group">
			  <label for="Manufact">Manufacture:</label>
			  <select class="form-control" id="Manufact" name="manufact_id">
				<option value="0">Select Manufacture</option>
				<?php
					$mafactListing1 = $obj->AllList('tbl_manufacturer_list','`status` = 1');
					$mafactListing = json_decode($mafactListing1,true);
					//print_r($listing1);
					if($mafactListing >= 1){
					foreach($mafactListing as $manufacture){ 
				?>
				<option value="<?php echo $manufacture['id'];?>"><?php echo $manufacture['manufactor_name'];?></option>
				<?php }
				} ?>
			  </select>
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
			  <label for="Model">Model Name:</label>
			  <input type="text" class="form-control" id="Model" placeholder="Enter Model Name" name="model">
			</div>
			</div>
			</div>
			
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
				<label for="color">Model Color:</label>
				<input type="text" class="form-control" id="color" placeholder="Enter Model Color" name="color">
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
				<label for="model_year">Model Year:</label>
				<input type="text" class="form-control" id="model_year" placeholder="Enter Model Year" name="model_year">
			</div>
			</div>
			</div>
			
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
				<label for="registration_no">Registration No.:</label>
				<input type="text" class="form-control" id="registration_no" placeholder="Enter Model Registration No." name="registration_no">
			</div>
			</div>
			<div class="col-md-6">
			<div class="form-group">
				<label for="description">Description:</label>
				<textarea name="description" id="description" class="form-control" placeholder="Type Description"></textarea>
			</div>
			</div>
			</div>
			<div class="row">
			<div class="col-md-6">
			<div class="form-group">
			  <label for="manufactStatus">Status:</label>
			  <select class="form-control" id="manufactStatus" name="status">
				<option value="1">Enable</option>
				<option value="0">Disable</option>
			  </select>
			  <input type="hidden" name="action" value="add">
			</div>
			</div>
			</div>
			<div class="row">
			<div class="col-md-6"></div>
			<div class="col-md-6">
			<button type="submit" name="AddModel" class="btn btn-primary">Add</button>
			</div>
			</div>
		  </form>
		  <div class="row">
			<table class="table table-hover">
				<thead>
				  <tr>
					<th>S.No.</th>
					<th>Model Name</th>
					<th>Model Color</th>
					<th>Status</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
					<?php
					$listing = $obj->AllList('tbl_model_list','`status` = 1 or `status` = 0');
					$listing1 = json_decode($listing,true);
					//print_r($listing1);
					if($listing1 >= 1){
					foreach($listing1 as $model){
					$count += 1;
					?>
					  <tr>
						<td><?php echo $count; ?></td>
						<td><?php echo ucfirst($model['model_name']); ?></td>
						<td><?php echo ucfirst($model['model_color']); ?></td>
						<td><?php if($model['status'] == 1){echo '<span class="btn btn-success">Enabled</span>';}else{echo '<div class="btn btn-primary">Disable</div>';}; ?></td>
						<td>
							<a href="viewModel.php?id=<?php echo $model['id']; ?>" class="btn btn-info viewManufact">Edit</a>
							<button type="button" class="btn btn-danger deleteModel" data-ids="<?php echo $model['id']; ?>">Delete</button>
						</td>
					  </tr>
					<?php } 
					} ?>
				</tbody>
			  </table>
		  </div>
		</div>
		 <script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script>
		$('.deleteModel').on('click',function(){
			var DelId = $(this).attr('data-ids');
			var isOk = confirm('Do You really want to delete?');
			if(isOk == true){
				window.location.href = 'api/delete.php?table=tbl_manufacturer_list&id='+DelId;
			}
			
		});
		</script>
	</body>
</html>
